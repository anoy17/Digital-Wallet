<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>History</title>
<style>
		table, thead, tbody, tr, th, td {
		border: 1px solid black;
		}
	</style>
</head>
<body>

<h1> Page 3 [Transaction History] </h1>

<legend><b>Digital Wallet</b></legend>
<br>
<a href = Page 1 [Home].php> 1.Home</a>      
<a href = Page 2 [Add Beneficiary].php> 2.Add Beneficiary</a>
<a href = Page 3 [Transaction Hitory].php> 3.Transaction Hitory</a>
<br>
<br>
<label for="from">From:</label>

<input type="date" name="from">
<label for="to">To<label>

<input type="date" name="to">
<input type="submit" value="Search" >
<br>
<br>
<label><b>Total Records</b></label>


</body>
</html>